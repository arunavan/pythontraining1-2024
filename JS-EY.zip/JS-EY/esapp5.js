var num = 32 

var result = num > 0 ?"positive":"non-positive" 

console.log(result)


let source_arr = [10,20,30]
   let dest_arr = [...source_arr]
   console.log(dest_arr)

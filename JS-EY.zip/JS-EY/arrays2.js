var num = new Array(5); // This single numeric value indicates the size of array.  
var i;  
for(i=0;i<num.length;i++){  
num[i]=i*5;  
console.log(num[i]);  
}  
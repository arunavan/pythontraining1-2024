console.log("welcome to typescript");
var cname = "User";
console.log(cname);
var msg = '';
console.log(msg);



//let sum1=(a,b)=>a+b;

//console.log(sum1(5,6));
console.log("arraow functions");

let sumsq1= (a,b) => a*a*a+b*b*b;

let diff=(x,y) => x-y;

console.log(sumsq1(3,2));
console.log(diff(3,2));

var sum = (a, b) => {
    let result =  a + b;
  return "Sum is" + result;
};

console.log(sum(5, 3));
from django.shortcuts import render
from django.http import HttpResponse
     
def hello_world(request):
   return HttpResponse("Hello World!")

def getemi(request):
   return HttpResponse(" emi Amount is 99999.99!")
